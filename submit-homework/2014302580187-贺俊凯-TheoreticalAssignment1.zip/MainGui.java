import java.text.DecimalFormat;
import java.util.*;
import java.io.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import org.jsoup.select.*;
import org.jsoup.*;
import org.jsoup.nodes.*;
import jxl.write.*;
import jxl.write.Label;
import jxl.*;

class Info
{
	public String strs[] = new String[10];
	public boolean m_IsBigger(Info other)
	{
		double i1 = Double.parseDouble(this.strs[9]);
		double i2 = Double.parseDouble(other.strs[9]);
		if(i1>i2)
		{
		    return true;
		}
		else 
			return false;
	}
	
};

class ButtonController implements ActionListener 
{

	private boolean theButtonClicked ;
	ButtonController(boolean b)
	{
		theButtonClicked = b;
	}
	
	@Override
	public void actionPerformed(ActionEvent e)  {
		// TODO Auto-generated method stub
		if(theButtonClicked == true)
		{
			MainGui out2xls = new MainGui();		
			try{
				out2xls.processScoreTable(new File("C:\\Users\\SilverCrux\\Desktop\\test.html"));
		        }
		    catch(Exception IOException)
		       {
			
		        }
		//System.out.println("you push it");
	     }
		else
			System.exit(0);
	}
}

class ButtonPanel extends JPanel
{
	ButtonPanel()
	{
		JButton toXls = new JButton("��ʼ���");
		JButton cancel = new JButton("�˳�");
		
		ButtonController outputClicked = new ButtonController(true);
		ButtonController cancelClicked = new ButtonController(false);
		toXls.addActionListener(outputClicked);
		cancel.addActionListener(cancelClicked);
		
		this.add(toXls);
		this.add(cancel);
	}
}

public class MainGui {
	public static void main(String[] args) throws IOException,Exception
	{
		creatAndShowGui();
		//processScoreTable(file);

	}
	
	public static void creatAndShowGui(){
		JFrame frame = new JFrame("����ɼ���");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(new ButtonPanel());
		frame.pack();
		frame.setVisible(true);
	}
	
	
	public void processScoreTable(File input) throws IOException,Exception
	{
		Document doc = Jsoup.parse(input,"UTF-8","");
		Elements bodys = doc.select("td");
		ArrayList<Info> m_info = new ArrayList<Info>();
		m_Load(bodys,m_info);
		WritableWorkbook test = Workbook.createWorkbook(new File("C:\\Users\\SilverCrux\\Desktop\\�ؿ���.xls"));
		WritableSheet sheet = test.createSheet("�ɼ���",0);
		m_Sort(m_info);
		int n=0;
		double gpalist[] = new double[2];
		m_Count(gpalist,m_info);
		DecimalFormat df = new DecimalFormat( "0.0000"); 
		String GPA = df.format(gpalist[0]);
		String Ave = df.format(gpalist[1]);
		System.out.println(GPA);
		while(n!=m_info.size())
		{
			Label tmp1 = new Label(0,n,m_info.get(n).strs[0]);
			Label tmp2 = new Label(1,n,m_info.get(n).strs[1]);
			Label tmp3 = new Label(2,n,m_info.get(n).strs[2]);
			Label tmp4 = new Label(3,n,m_info.get(n).strs[3]);
			Label tmp5 = new Label(4,n,m_info.get(n).strs[4]);
			Label tmp6 = new Label(5,n,m_info.get(n).strs[5]);
			Label tmp7 = new Label(6,n,m_info.get(n).strs[6]);
			Label tmp8 = new Label(7,n,m_info.get(n).strs[7]);
			Label tmp9 = new Label(8,n,m_info.get(n).strs[8]);
			Label tmp10 = new Label(9,n,m_info.get(n).strs[9]);
			sheet.addCell(tmp1);
			sheet.addCell(tmp2);
			sheet.addCell(tmp3);
			sheet.addCell(tmp4);
			sheet.addCell(tmp5);
			sheet.addCell(tmp6);
			sheet.addCell(tmp7);
			sheet.addCell(tmp8);
			sheet.addCell(tmp9);
			sheet.addCell(tmp10);
			n++;
		}
		Label ave = new Label(0,m_info.size(),"��Ȩƽ����");
		Label gpa = new Label(0,m_info.size()+1,"�ۺϼ�ȨGPA");
		Label gpanum = new Label(1,m_info.size()+1,GPA);
		Label avenum = new Label(1,m_info.size(),Ave);
		sheet.addCell(gpa);
		sheet.addCell(ave);
		sheet.addCell(avenum);
		sheet.addCell(gpanum);
		test.write();
		test.close();
	}
	
	public static void m_Load(Elements bodys,ArrayList<Info> m_info)
	{
		int n = 0;
		while(bodys.get(n+9).text().equals("")!=true)
		{
     		int i = n;
			int num = 10+n;
			Info tmp = new Info();
			for(;i<num;i++)
		    {
				tmp.strs[10-num+i] = bodys.get(i).text();
				//m_info.strs.add(bodys.get(i).text());
			}
			m_info.add(tmp);
			n+=11;
		}
	}
	
	public static void m_Sort(ArrayList<Info> m_info)
	{
		ArrayList<Info> m_tmp = new ArrayList<Info>();
		int n = 0;
		while(n!=m_info.size())
		{
			if(n==0)
			{
				m_tmp.add(m_info.get(n));
			}
			else 
			{
				int i = 0;
				while(i!=m_tmp.size())
				{
					if(m_info.get(n).m_IsBigger(m_tmp.get(i)))
					{
						m_tmp.add(i, m_info.get(n));
						break;
					}
					else 
					{
						if(i == m_tmp.size()-1)
							{
							    m_tmp.add(m_info.get(n));
							    break;
							}
						   
						else
							i++;
					}
				}
			}
			n++;
		}
		m_info.clear();
		m_info.addAll(m_tmp);
	}
	
	public static void m_Count(double gpalist[],ArrayList<Info> m_info)
{
		double gpa[] = new double[m_info.size()];
		double score[] = new double[m_info.size()];
		double credit[] = new double[m_info.size()];
		int n = 0;
		while(n!=m_info.size())
		{
			credit[n] = Double.parseDouble(m_info.get(n).strs[3]);
			score[n] = Double.parseDouble(m_info.get(n).strs[9]);
			if(score[n]>=90)
			{
				gpa[n]=4;
			}
			else
			{
				if(score[n]<=89&&score[n]>=85)
				{
					gpa[n] = 3.7;
				}
				else
					if(score[n]<=84&&score[n]>=82)
					{
						gpa[n] = 3.3;
					}
					else
						if(score[n]>=78&&score[n]<=81)
						{
							gpa[n]=3;
						}
						else
							if(score[n]>=75&&score[n]<=77)
							{
								gpa[n]=2.7;
							}
							else
								if(score[n]>=72&&score[n]<=74)
								{
									gpa[n]=2.3;
								}
								else
									if(score[n]>=68&&score[n]<=71)
									{
										gpa[n]=2.0;
									}
									else
										if(score[n]>=64&&score[n]<=67)
										{
											gpa[n]=1.5;
										}
										else
											if(score[n]>=60&&score[n]<=63)
											{
												gpa[n]=1.0;
											}
											else
												gpa[n]=0;
			}
			n++;
		}
		n=0;
		double gpasum = 0;
		double scoresum = 0;
		double creditsum = 0;
		while(n!=m_info.size())
		{
			creditsum += credit[n];
			scoresum += score[n]*credit[n];
			gpasum += gpa[n]*credit[n];
			n++;
		}
		gpalist[0] = gpasum / creditsum;
		gpalist[1] = scoresum / creditsum;
}
}
